ALTER TABLE public.clients ADD COLUMN IF NOT EXISTS instagram text;
